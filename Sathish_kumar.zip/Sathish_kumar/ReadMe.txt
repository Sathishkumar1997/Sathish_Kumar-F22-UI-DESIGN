NAME: Sathishkumar N.
DEPARTMENT: Electrical & Electronics.
COLLEGE: Jeppiaar Engineering College.


As i applied for the Front enf UI designer(intern), i have been given a test to create a weppage under some conditions. As an electrical student with some interest and knowledge on webdesigning, i designed these pages. And learned a lot about webdesigning through this project. And i assure you that the whole webpage was created by my own hands. With the best of my knowledge i completed the test assigned to me. And Finally i am thanking you for giving me this opportunity to learn something about this field.


